//:Just another lorem-ipsum generator
//:LoremIpsum generator:  #blocks: number of blocks to generate #set: the text »suite« to use #offset: the »start« inside the »suite« #repeat: how often to repeat the text
// v 0.2.0
if (!isset($blocks)) $blocks = 1;
if (!isset($set)) $set = 'lorem';
if (!isset($offset)) $offset = 0;
if (!isset($repeat)) $repeat = 1;

require_once( LEPTON_PATH."/modules/lib_loremgen/library.php" );

return LEPTON_loremgen::getInstance()->lorem2( $set, $blocks, $offset, $repeat );