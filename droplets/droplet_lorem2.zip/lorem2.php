//:Just another LoremIpsum generator
//:Params are: set = lorem/berthold/fun/css/img/form blocks = 1 .. n offset = 1 .. n repeat = n times
if (!isset($blocks)) $blocks = 1;
if (!isset($set)) $set = 'lorem';
if (!isset($offset)) $offset = 0;
if (!isset($repeat)) $repeat = 1;
if (!isset($max)) $max = 0;

return lib_loremGen::getInstance()->lorem2( $set, $blocks, $offset, $repeat, $max );
