//:Just another lorem-ipsum generator
//:
if (!isset($blocks)) $blocks = 1;
if (!isset($set)) $set = 'lorem';
if (!isset($offset)) $offset = 0;
if (!isset($repeat)) $repeat = 1;

require_once( LEPTON_PATH."/modules/lib_loremgen/library.php" );
global $loremgen;
if(!is_object($loremgen)) $loremgen = new LEPTON_loremgen();
return $loremgen->lorem2( $set, $blocks, $offset, $repeat );